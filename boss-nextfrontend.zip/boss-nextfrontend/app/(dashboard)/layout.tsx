"use client";

import { useState, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useAuth } from "@/app/contexts/AuthContext";
import Sidebar from "../navigation/Sidebar";
import Header from "../navigation/Header";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { isAuthenticated } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!isAuthenticated) {
      router.push(`/auth/login?from=${pathname}`);
    }
  }, [isAuthenticated, router, pathname]);
//  Avoids flashing protected content if user is not logged in.
  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      <Sidebar />

      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <Header onOpenSidebar={() => setSidebarOpen(true)} />

        <main className="relative md:ml-64 flex-1 overflow-y-auto focus:outline-none p-4 md:p-6">
          <div className="mx-auto max-w-7xl">{children}</div>
        </main>
      </div>
    </div>
  );
}
