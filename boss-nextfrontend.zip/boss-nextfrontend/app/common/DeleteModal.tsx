import { useState } from "react";
import { X } from "lucide-react";
import Alert from "@/app/common/Alert";
import Button from "@/app/common/Button";

interface ConfirmModalProps {
  isOpen: boolean;
  title?: string;
  name: string;
  confirmLabel?: string;
  cancelLabel?: string;
  onClose: () => void;
  onConfirm: () => Promise<void> | void; // delete confirmation will make call to delete the selected object
}

const ConfirmModal = ({
  isOpen,
  title = "Confirm Action",
  name,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  onClose,
  onConfirm,
}: ConfirmModalProps) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleConfirm = async () => {
    setErrorMessage(null);
    setLoading(true);
    try {
      await onConfirm();
      onClose();
    } catch (error: any) {
      setErrorMessage(error.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

    return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 text-center sm:block sm:p-0">
        <div
          className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
          onClick={onClose}
        ></div>

        <div className="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-md sm:w-full">
          <div className="bg-white dark:bg-gray-800 px-6 pt-5 pb-4 sm:p-6 sm:pb-4">
            <div className="flex justify-between items-start">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                {title}
              </h3>
              <button
                onClick={onClose}
                className="rounded-md text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {errorMessage && (
              <Alert type="error" onClose={() => setErrorMessage(null)}>
                {errorMessage}
              </Alert>
            )}

            <p className="mt-4 text-sm text-gray-600 dark:text-gray-300">
              Are you sure you want to delete {name}?
            </p>
          </div>

          <div className="bg-gray-50 dark:bg-gray-900 px-6 py-3 sm:flex sm:flex-row-reverse sm:gap-3">
            <Button type="button" loading={loading} onClick={handleConfirm}>
              {confirmLabel}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="mt-3 sm:mt-0"
            >
              {cancelLabel}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;
