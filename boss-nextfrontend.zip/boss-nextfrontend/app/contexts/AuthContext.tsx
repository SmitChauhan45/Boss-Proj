import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";
import { useApolloClient, useLazyQuery } from "@apollo/client";
import { jwtDecode } from "jwt-decode";
import { CURRENT_USER } from "../../lib/graphql/queries";
import { User } from "../types";

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  initialized: boolean;
  login: (token: string, user: User) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [initialized, setInitialized] = useState(false);

  const client = useApolloClient();
  //getCurrentUser() is called only if a valid token exists.
  const [getCurrentUser] = useLazyQuery(CURRENT_USER, {
    onCompleted: (data) => {
      if (data.me) {
        setUser(data.me);
      } else {
        logout();
      }
      setInitialized(true);
    },
    onError: () => {
      logout();
      setInitialized(true);
    },
  });

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      setInitialized(true);
      return;
    }

    try {
      const decoded: any = jwtDecode(token);
      const now = Date.now() / 1000;

      if (decoded.exp && decoded.exp < now) {
        logout();
      } else {
        getCurrentUser();
      }
    } catch (err) {
      logout();
    } finally {
      setInitialized(true);
    }
  }, []);

  const login = (token: string, userData: User) => {
    localStorage.setItem("token", token);
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
    client.resetStore();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        initialized,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
