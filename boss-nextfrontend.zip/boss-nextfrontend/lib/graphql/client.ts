import {
  ApolloClient,
  InMemoryCache,
  createHttpLink,  //for creting Http connection to graphql end point 
  ApolloLink,// for creating middleware chains 
} from "@apollo/client"
// this basically creates the direct connection  to your GraphQl server
const httpLink = createHttpLink({
  uri: "http://localhost:5000/graphql",// uniform resourse identifier( broder term )
})




//Represents the GraphQL Operation being executed, not just an HTTP request.
// operation contains details about (query,variables,context)
const authMiddleware = new ApolloLink((operation, forward) => {
  const token = localStorage.getItem("token")

  operation.setContext(({ headers = {} }) => ({
    headers: {
      ...headers,
      authorization: token ? `Bearer ${token}` : "",
    },
  }))

  return forward(operation)
})

const client = new ApolloClient({
  link: authMiddleware.concat(httpLink),
  cache: new InMemoryCache(),
})

export default client