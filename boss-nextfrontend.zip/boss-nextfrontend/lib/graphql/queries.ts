import { gql } from "@apollo/client";

export const CURRENT_USER = gql`
  query Me {
    me {
      id
      name
      email
      role
    }
  }
`;
// not used item array here because it is not needed in the dashboard page
export const GET_WAREHOUSES = gql`
  query GetWarehouses {
    warehouses {
      id
      name
      location
      totalCapacity
      availableSpace
      storageTypes {
        type
        capacity
      }
      items {
        id
        name
        quantity
        size
      }
    }
  }
`;

export const GET_WAREHOUSE = gql`
  query GetWarehouse($id: ID!) {
    warehouse(id: $id) {
      id
      name
      location
      totalCapacity
      availableSpace
      storageTypes {
        type
        capacity
      }
      items {
        id
        name
        description
        quantity
        storageType
        size
        totalSpaceUsed
      }
    }
  }
`;

export const GET_ITEMS = gql`
  query GetItems($warehouseId: ID!) {
    items(warehouseId: $warehouseId) {
      id
      name
      description
      quantity
      storageType
      size
      totalSpaceUsed
      warehouse {
        id
        name
      }
    }
  }
`;
export const GET_ALL_ITEMS = gql`
  query GetAllItems {
    allItems {
      id
      name
      description
      quantity
      size
      storageType
      warehouse {
        id
        name
      }
    }
  }
`;
