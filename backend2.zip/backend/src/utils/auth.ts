import jwt from "jsonwebtoken";
import { JWT_SECRET } from "../config/config";
import { IUser, User } from "../models/User";
// represents the data shape stored inside the token
export interface AuthUser {
  id: string;
  role: "admin" | "staff";
  name: string;
}

export function generateToken(user: IUser): string {
  return jwt.sign(
    { id: user.id, role: user.role, name: user.name },
    JWT_SECRET,
    { expiresIn: "1d" }
  );
}


export async function getUserFromToken(
  token?: string
): Promise<AuthUser | null> {
  if (!token) return null;
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthUser;
    const user = await User.findById(decoded.id);
    if (!user) return null;
    return { id: user.id, role: user.role, name: user.name };
  } catch {
    return null;
  }
}
