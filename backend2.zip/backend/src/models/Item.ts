import { Schema, model, Document, Types } from "mongoose";

export interface IItem extends Document {
  warehouse: Types.ObjectId;
  name: string;
  description?: string;
  quantity: number;
  storageType: string;
  size: number;
}

//interface for incomming arguments
export interface ItemArgs {
  warehouseId: string;
  name: string;
  description: string;
  quantity: number;
  storageType: string;
  size: number;
}

export interface ItemUpdateArgs {
  id: string;
  warehouseId: string;
  name: string;
  description: string;
  quantity: number;
  storageType: string;
  size: number;
}

const itemSchema = new Schema<IItem>({
  warehouse: { type: Schema.Types.ObjectId, ref: "Warehouse", required: true },
  name: { type: String, required: true },
  description: { type: String },
  quantity: { type: Number, required: true },
  storageType: { type: String, required: true },
  size: { type: Number, required: true },
});

export const Item = model<IItem>("Item", itemSchema);
