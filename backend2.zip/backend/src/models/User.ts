import mongoose, { Schema, model, Document } from "mongoose";

export interface IUser extends Document {
  name: string;
  email: string;
  password: string;
  role: "admin" | "staff";
}
//register incoming arugments
export interface IRegisterArgs {
  name: string;
  email: string;
  password: string;
}
//login incoming arguments
export interface ILoginArgs {
  email: string;
  password: string;
}

const userSchema = new Schema<IUser>({
  name: { type: String, required: true, minlength: 3 },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
  },
  password: { type: String, required: true, minlength: 6 },
  role: { type: String, enum: ["admin", "staff"], default: "staff" },
});

export const User = model<IUser>("User", userSchema);
