import { Schema, model, Document } from "mongoose";

export interface IStorageType {
  type: string;
  capacity: number;
}

export interface IWarehouse extends Document {
  name: string;
  location: string;
  storageTypes: IStorageType[];
  totalCapacity: number;
  availableSpace: number;
}
//warehouse incoming arguments

//create warehouse args// user jo info de sakta h
export interface IWareHouseArgs {
  name: string;
  location: string;
  storageTypes: [IStorageType];
  totalCapacity: number;
}

//delete warehouse arguments
export interface IDeleteArgs {
  id: string;
}
//update warehouse args
export interface IWareHouseUpdateArgs {
  id: string;
  name: string;
  location: string;
  storageTypes: [IStorageType];
  totalCapacity: number;
}
const storageTypeSchema = new Schema<IStorageType>({
  type: { type: String, required: true },
  capacity: { type: Number, required: true },
});

const warehouseSchema = new Schema<IWarehouse>({
  name: { type: String, required: true },
  location: { type: String, required: true },
  storageTypes: { type: [storageTypeSchema], default: [] },
  totalCapacity: { type: Number, required: true },
  availableSpace: { type: Number, required: true },
});

export const Warehouse = model<IWarehouse>("Warehouse", warehouseSchema);
