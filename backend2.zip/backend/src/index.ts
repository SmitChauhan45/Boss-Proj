import express from "express";
import { ApolloServer } from "apollo-server-express";
import { typeDefs } from "./graphql/typeDef/schema";
import { resolvers } from "./graphql/resolvers";
import { PORT } from "./config/config";
import { connectDB } from "./config/db";
import { getUserFromToken } from "./utils/auth";

const startServer = async () => {
  await connectDB();

  const app = express();

  const server = new ApolloServer({
    typeDefs,
    resolvers,
    context: async ({ req }) => {
      const authHeader = req.headers.authorization || "";
      const token = authHeader.startsWith("Bearer ")
        ? authHeader.slice(7)
        : undefined;

      const user = await getUserFromToken(token);
      console.log(user);
      return { user };
    },
  });

  await server.start();

  server.applyMiddleware({ app, path: "/graphql" });

  app.listen(PORT, () => {
    console.log(
      `Server ready at http://localhost:${PORT}${server.graphqlPath}`
    );
  });
};
startServer();
