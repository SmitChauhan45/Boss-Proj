import { Warehouse } from "../models/Warehouse";
import { Item } from "../models/Item";
import {
  register,
  login,
  createWarehouse,
  updateWarehouse,
  deleteWarehouse,
  createItem,
  updateItem,
  deleteItem,
} from "./resolvers/index";
import { User } from "../models/User";

export const resolvers = {
  Query: {
    me: async (_parent: any, _args: any, context: any) => {
      if (!context.user?.id) return null;

      const user = await User.findById(context.user.id);
      return user;
    },

    //get all warehouses
    warehouses: async () => Warehouse.find(),

    //get warehouse by id
    warehouse: async (_: any, { id }: { id: string }) => Warehouse.findById(id),

    //get items by warehouseid
    items: async (_: any, { warehouseId }: { warehouseId: string }) =>
      Item.find({ warehouse: warehouseId }),

    //get all items
    allItems: async () => Item.find(),
  },

  Mutation: {
    //authentication
    register,
    login,

    //warehouse
    createWarehouse,
    deleteWarehouse,
    updateWarehouse,

    //items
    createItem,
    updateItem,
    deleteItem,
  },

  Warehouse: {
    items: async (parent: any) => Item.find({ warehouse: parent.id }),
  },

  Item: {
    warehouse: async (parent: any) => Warehouse.findById(parent.warehouse),
    totalSpaceUsed: (parent: any) => parent.quantity * parent.size,
  },
};
