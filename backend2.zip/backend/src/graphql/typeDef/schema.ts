import { gql } from "apollo-server";

export const typeDefs = gql`
  enum Role {
    admin
    staff
  }

  type User {
    id: ID!
    name: String!
    email: String!
    role: Role!
  }

  type StorageType {
    type: String!
    capacity: Float!
  }

  type Warehouse {
    id: ID!
    name: String!
    location: String!
    storageTypes: [StorageType!]!
    totalCapacity: Float!
    availableSpace: Float!
    items: [Item!]!
  }

  type Item {
    id: ID!
    warehouse: Warehouse!
    name: String!
    description: String
    quantity: Int!
    storageType: String!
    size: Float!
    totalSpaceUsed: Float!
  }

  type AuthPayload {
    token: String!
    user: User!
  }

  input StorageTypeInput {
    type: String!
    capacity: Float!
  }

  type Query {
    me: User
    warehouses: [Warehouse!]!
    warehouse(id: ID!): Warehouse
    items(warehouseId: ID!): [Item!]!
    allItems: [Item!]!
  }

  type Mutation {
    register(name: String!, email: String!, password: String!): AuthPayload!
    login(email: String!, password: String!): AuthPayload!

    createWarehouse(
      name: String!
      location: String!
      storageTypes: [StorageTypeInput!]!
      totalCapacity: Float!
    ): Warehouse!

    updateWarehouse(
      id: ID!
      name: String
      location: String
      storageTypes: [StorageTypeInput!]
      totalCapacity: Float
    ): Warehouse!

    deleteWarehouse(id: ID!): Boolean!

    createItem(
      warehouseId: ID!
      name: String!
      description: String
      quantity: Int!
      storageType: String!
      size: Float!
    ): Item!

    updateItem(
      id: ID!
      name: String
      description: String
      quantity: Int
      storageType: String
      size: Float
    ): Item!

    deleteItem(id: ID!): Boolean!
  }
`;
