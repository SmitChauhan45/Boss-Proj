import { ApolloError, AuthenticationError } from "apollo-server";
import { IDeleteArgs, Warehouse } from "../../models/Warehouse";
import { Item } from "../../models/Item";

// delete warehouse logic
export const deleteWarehouse = async (
  _: unknown,
  args: IDeleteArgs,
  context: any
): Promise<boolean> => {
  if (!context.user) throw new AuthenticationError("Not authenticated");
  if (context.user.role !== "admin")
    throw new ApolloError("Only admin can delete warehouses");

  const items = await Item.find({ warehouse: args.id });
  if (items.length > 0)
    throw new ApolloError("Cannot delete warehouse with stored items");

  await Warehouse.findByIdAndDelete(args.id);
  return true;
};

//delete item
export const deleteItem = async (
  _: unknown,
  args: IDeleteArgs,
  context: any
): Promise<boolean> => {
  if (!context.user) throw new AuthenticationError("Not authenticated");
  if (context.user.role !== "admin")
    throw new ApolloError("Only admin can delete Items");

  const item = await Item.findById(args.id);
  if (!item) throw new ApolloError("Item not found");

  const warehouse = await Warehouse.findById(item.warehouse);
  if (!warehouse) throw new ApolloError("Warehouse not found");

  const spaceFreed = item.quantity * item.size;

  await item.deleteOne();

  warehouse.availableSpace += spaceFreed;
  await warehouse.save();

  return true;
};
