import { AuthenticationError } from "apollo-server";
import { Warehouse, IWareHouseUpdateArgs } from "../../models/Warehouse";
import { IWarehouse } from "../../models/Warehouse";
import { ApolloError } from "apollo-server";
import { IItem, Item, ItemUpdateArgs } from "../../models/Item";

// update warehouse
export const updateWarehouse = async (
  _: unknown,
  args: IWareHouseUpdateArgs,
  context: any
): Promise<IWarehouse> => {
  if (!context.user) throw new AuthenticationError("Not authenticated");
  if (!["admin", "staff"].includes(context.user.role))
    throw new ApolloError("Not authorized");

  const warehouse = await Warehouse.findById(args.id);
  if (!warehouse) throw new ApolloError("Warehouse not found");

  if (args.name !== undefined) warehouse.name = args.name;
  if (args.location !== undefined) warehouse.location = args.location;
  if (args.storageTypes !== undefined)
    warehouse.storageTypes = args.storageTypes;

  if (args.totalCapacity !== undefined) {
    const usedSpace = warehouse.totalCapacity - warehouse.availableSpace;
    if (args.totalCapacity < usedSpace)
      throw new ApolloError("Total capacity cannot be less than used space");
    warehouse.totalCapacity = args.totalCapacity;
    warehouse.availableSpace = args.totalCapacity - usedSpace;
  }

  await warehouse.save();
  return warehouse;
};

//update item
export const updateItem = async (
  _: unknown,
  args: ItemUpdateArgs,
  context: any
): Promise<IItem> => {
  if (!context.user) throw new AuthenticationError("Not authenticated");
  if (!["admin", "staff"].includes(context.user.role))
    throw new ApolloError("Not authorized");

  const item = await Item.findById(args.id);
  if (!item) throw new ApolloError("Item not found");

  const warehouse = await Warehouse.findById(item.warehouse);
  if (!warehouse) throw new ApolloError("Warehouse not found");

  // Check if the requested storageType exists in the warehouse
  const storageExist = warehouse.storageTypes.some(
    (x) => x.type === args.storageType
  );
  if (!storageExist) {
    throw new ApolloError("Storage Type Not exist in the warehouse!");
  }

  const st = warehouse.storageTypes.find((x) => x.type === args.storageType);
  if (!st) {
    throw new ApolloError("Storage Type not found in the warehouse!");
  }

  const oldSpaceUsed = item.quantity * item.size;
  const newQuantity =
    args.quantity !== undefined ? args.quantity : item.quantity;
  const newSize = args.size !== undefined ? args.size : item.size;
  const newSpaceUsed = newQuantity * newSize;

  const spaceDifference = newSpaceUsed - oldSpaceUsed;

  // Check if there is enough space in the warehouse for the new item size
  if (spaceDifference > warehouse.availableSpace)
    throw new ApolloError(
      "Not enough available space in the warehouse for update"
    );

  // Check if there is enough space in the storage type for the new item size
  if (newSpaceUsed > st.capacity)
    throw new ApolloError(
      "Not enough available space in the item storage type"
    );

  // Update item properties if new values are provided
  if (args.name !== undefined) item.name = args.name;
  if (args.description !== undefined) item.description = args.description;
  if (args.quantity !== undefined) item.quantity = args.quantity;
  if (args.storageType !== undefined) item.storageType = args.storageType;
  if (args.size !== undefined) item.size = args.size;

  await item.save();

  // Update available space in the warehouse and storage type
  warehouse.availableSpace -= spaceDifference;
  st.capacity -= spaceDifference;

  await warehouse.save();

  return item;
};
