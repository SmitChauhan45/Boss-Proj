import { register, login } from "./authResolver";
import { createWarehouse, createItem } from "./addResolver";
import { updateWarehouse, updateItem } from "./updateResolver";

import { deleteWarehouse, deleteItem } from "./deleteResolver";
export {
  register,
  login,
  createWarehouse,
  updateWarehouse,
  deleteWarehouse,
  createItem,
  updateItem,
  deleteItem,
};
