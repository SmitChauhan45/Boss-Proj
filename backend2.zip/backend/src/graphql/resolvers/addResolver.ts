import { AuthenticationError } from "apollo-server";
import { Warehouse, IWareHouseArgs } from "../../models/Warehouse";
import { IWarehouse } from "../../models/Warehouse";
import { ApolloError } from "apollo-server";
import { IItem, Item, ItemArgs } from "../../models/Item";

//create warehouse logic
export const createWarehouse = async (
  _: unknown,
  args: IWareHouseArgs,
  context: any
): Promise<IWarehouse> => {
  if (!context.user) throw new AuthenticationError("Not authenticated");
  if (!["admin", "staff"].includes(context.user.role))
    throw new ApolloError("Not authorized");

  const warehouse = new Warehouse({
    name: args.name,
    location: args.location,
    storageTypes: args.storageTypes,
    totalCapacity: args.totalCapacity,
    availableSpace: args.totalCapacity,
  });
  await warehouse.save();
  return warehouse;
};

//create item
export const createItem = async (
  _: unknown,
  args: ItemArgs,
  context: any
): Promise<IItem> => {
  if (!context.user) throw new AuthenticationError("Not authenticated");
  if (!["admin", "staff"].includes(context.user.role))
    throw new ApolloError("Not authorized");

  const warehouse = await Warehouse.findById(args.warehouseId);
  if (!warehouse) throw new ApolloError("Warehouse not found");

  const st = warehouse.storageTypes.find((x) => x.type === args.storageType);
  if (!st) {
    throw new ApolloError("Storage Type does not  exist in the warehouse!");
  }

  const totalSpaceNeeded = args.quantity * args.size;

  if (totalSpaceNeeded > st.capacity) {
    throw new ApolloError("Not enough available space in item storage type");
  }

  if (totalSpaceNeeded > warehouse.availableSpace) {
    throw new ApolloError("Not enough available space in the warehouse");
  }

  const item = new Item({
    warehouse: args.warehouseId,
    name: args.name,
    description: args.description,
    quantity: args.quantity,
    storageType: args.storageType,
    size: args.size,
  });

  await item.save();

  // Update storage type capacity
  st.capacity -= totalSpaceNeeded;
  warehouse.availableSpace -= totalSpaceNeeded;

  // Save the warehouse after updates
  await warehouse.save();

  return item;
};
