import { AuthenticationError, UserInputError } from "apollo-server";
import { ILoginArgs, IUser } from "../../models/User";
import { IRegisterArgs } from "../../models/User";
import { User } from "../../models/User";
import bcrypt from "bcryptjs";
import { generateToken } from "../../utils/auth";

//register
export const register = async (
  _: unknown,
  args: IRegisterArgs
): Promise<{ user: IUser }> => {
  const { name, email, password } = args;
  const existingUser = await User.findOne({ email });
  if (existingUser) throw new UserInputError("Email already registered");
  const hashedPassword = await bcrypt.hash(password, 10);

  const user = new User({
    name,
    email,
    password: hashedPassword,
    role: "staff",
  });
  await user.save();
  return { user };
};

//login
export const login = async (
  _: unknown,
  args: ILoginArgs
): Promise<{ token: string; user: IUser }> => {
  const user = await User.findOne({ email: args.email });
  if (!user) throw new AuthenticationError("Invalid credentials");
  const valid = await bcrypt.compare(args.password, user.password);
  if (!valid) throw new AuthenticationError("Invalid credentials");
  const token = generateToken(user);
  return { token, user };
};
