import mongoose from "mongoose";
import { MONGODB_URI } from "./config";

export async function connectDB() {
  try {
    console.log("Connecting to MongoDB...");
    await mongoose.connect(MONGODB_URI); 
    console.log("MongoDB connected successfully");
  } catch (error) {
    console.error("MongoDB connection failed:", error);
    process.exit(1); // Exit the process on connection failure
  }
}
